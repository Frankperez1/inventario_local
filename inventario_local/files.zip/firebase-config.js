// firebase-config.js - Datos del proyecto Firebase (son públicos, no son secretos).
// De dónde sacarlos: Firebase › ⚙ Configuración del proyecto › General › "Tus apps" › app web › "Configuración del SDK" › Config.
// Pegue cada valor entre las comillas. Mientras apiKey esté vacío, la app funciona solo en modo local (sin login ni nube).
window.FIREBASE_CONFIG = {
  apiKey: "",
  authDomain: "",
  projectId: "",
  storageBucket: "",
  messagingSenderId: "",
  appId: ""
};

// Opcional: más administradores (agregue los mismos correos en firestore.rules, función esAdminCorreo).
// window.FIREBASE_ADMINS = ["otro-admin@gmail.com"];
